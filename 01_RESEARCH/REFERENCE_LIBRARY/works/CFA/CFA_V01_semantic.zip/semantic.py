import zipfile,re,sys,hashlib,json,csv,collections, posixpath
from pathlib import Path
from lxml import etree
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import normalize
p=Path(sys.argv[1]); out=Path(sys.argv[2]);out.mkdir(exist_ok=True,parents=True)
z=zipfile.ZipFile(p); root=etree.fromstring(z.read('META-INF/container.xml')); opf=root.xpath('//*[local-name()="rootfile"]')[0].get('full-path'); r=etree.fromstring(z.read(opf)); folder=posixpath.dirname(opf)
manifest={x.get('id'):x.get('href') for x in r.xpath('//*[local-name()="manifest"]/*')}; rows=[]; texts=[]; scene=collections.Counter(); counts=collections.Counter(); files=[]
lex={'cognition':r'\b(?:think|thought|wonder(?:ed)?|realiz\w*|underst\w*|knew|know|notic\w*|suspect\w*|remember\w*)\b','uncertainty':r'\b(?:perhaps|maybe|probably|seem\w*|apparently|guess\w*|might|could)\b','decision':r'\b(?:decid\w*|resolv\w*|plan\w*|intend\w*|must|need(?:ed)? to|should|have to)\b','contrast':r'\b(?:but|however|yet|although|instead|despite)\b','causal':r'\b(?:because|so|therefore|thus|since|as a result)\b','conditional':r'\b(?:if|unless|otherwise|provided that)\b','emotion':r'\b(?:fear\w*|worr\w*|angr\w*|anger|relief|relieved|happy|sad|joy|surpris\w*|shock\w*|anxious|nervous|embarrass\w*)\b','conflict':r'\b(?:attack\w*|defen[ds]\w*|fight\w*|fought|struck|battle\w*|spell\w*|enemy|opponent\w*|threat\w*)\b','social':r'\b(?:trust\w*|loyal\w*|respect\w*|faith\w*|friend\w*|ally|allies|subordinate\w*|apolog\w*|gratitude|prais\w*)\b','resources':r'\b(?:cost\w*|price\w*|money|time|resource\w*|energy|mana|food|meal\w*|power|strength)\b','exposition':r'\b(?:mean\w*|refer\w*|explain\w*|in other words|known as|called|consist\w*|rule\w*)\b','temporal':r'\b(?:then|after|before|finally|later|meanwhile|suddenly|eventually)\b'}
rx={k:re.compile(v,re.I) for k,v in lex.items()}; tok=lambda s:re.findall(r"\b[\w]+(?:[’'\-][\w]+)*\b",s.lower())
for it in r.xpath('//*[local-name()="spine"]/*'):
 href=manifest[it.get('idref')]; m=re.fullmatch(r'Text/(prologue|chapter\d+)(?:_\d+)?\.xhtml',href)
 if not m:continue
 u=m[1];files.append(href);x=etree.fromstring(z.read(posixpath.join(folder,href)))
 if not scene[u]:scene[u]=1
 for i,a in enumerate(x.xpath('//*[local-name()="p"]'),1):
  s=''.join(a.itertext()).strip()
  if not s:continue
  if s=='§':scene[u]+=1;continue
  counts[u]+=1;w=tok(s);q=re.findall(r'“([^”]*)”|"([^"\n]*)"',s); qw=sum(len(tok(a or b)) for a,b in q); hits={k:len(v.findall(s)) for k,v in rx.items()}; names=[n for n in ['Zil','Roland','Kieran','Theodore','Stella','Chloe','Sanjel','Magia'] if re.search(r'\b'+n+r'\b',s,re.I)]; rows.append(dict(unit=u,paragraph=counts[u],scene=f'{u}-S{scene[u]:02}',file=href,xml_p=i,sha256=hashlib.sha256(s.encode()).hexdigest(),tokens=len(w),quote_tokens=qw,questions=s.count('?'),exclamations=s.count('!'),first_person=sum(w.count(v) for v in ['i','me','my','mine']),names=';'.join(names),**hits));texts.append(s)
# context window within explicit scene (no cross-scene contamination)
ctx=[' '.join(texts[j] for j in range(max(0,i-1),min(len(texts),i+2)) if rows[j]['scene']==r['scene']) for i,r in enumerate(rows)]
v=TfidfVectorizer(stop_words='english',ngram_range=(1,2),min_df=3,max_df=.8,max_features=10000,sublinear_tf=True);X=v.fit_transform(ctx);sv=TruncatedSVD(n_components=32,random_state=42);Y=normalize(sv.fit_transform(X));km=KMeans(n_clusters=18,n_init=10,random_state=42);cl=km.fit_predict(Y); terms=np.array(v.get_feature_names_out()); center=sv.inverse_transform(km.cluster_centers_); topics={str(i):{'top_terms':terms[np.argsort(c)[-10:][::-1]].tolist(),'count':int(sum(cl==i))} for i,c in enumerate(center)}
for i,r in enumerate(rows):
 r['cluster']=int(cl[i]); r['quote_share']=round(r['quote_tokens']/max(r['tokens'],1),3); r['candidate_roles']=';'.join([k for k in lex if r[k]]+(['quoted_speech_proxy'] if r['quote_tokens'] else [])+(['question'] if r['questions'] else [])) or 'unclassified'; r['review_status']='automatic_unverified'
def write(name,rs):
 with (out/name).open('w',newline='',encoding='utf8') as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
write('paragraphs.csv',rows)
scenes=[]; samples=[]
for sid in dict.fromkeys(r['scene'] for r in rows):
 ids=[i for i,r in enumerate(rows) if r['scene']==sid]; rr=[rows[i] for i in ids]; c=collections.Counter(r['cluster'] for r in rr); n=len(ids);scenes.append(dict(scene=sid,unit=rr[0]['unit'],start=rr[0]['paragraph'],end=rr[-1]['paragraph'],paragraphs=n,tokens=sum(r['tokens'] for r in rr),quote_tokens=sum(r['quote_tokens'] for r in rr),dominant_clusters=';'.join(str(k) for k,_ in c.most_common(3)),**{k:sum(r[k] for r in rr) for k in lex},questions=sum(r['questions'] for r in rr),review_status='automatic_unverified'))
 # excerpts for private reviewer only, not in deliverable
 chosen=sorted(set([ids[0],ids[-1],ids[n//2]]+[max(ids,key=lambda i:rows[i][k]) for k in ['decision','cognition','social','conflict']]))
 samples.append(f'\n{sid} ({rr[0]["paragraph"]}-{rr[-1]["paragraph"]}) '+str(c.most_common(2))+'\n'+'\n'.join(f'{rows[i]["paragraph"]}: {texts[i][:430]}' for i in chosen))
write('scenes.csv',scenes); (out/'clusters.json').write_text(json.dumps(topics,indent=2)); (out/'method.json').write_text(json.dumps({'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'units':dict(counts),'files':len(files),'paragraphs':len(rows),'tokens':sum(r['tokens'] for r in rows),'scenes':len(scenes),'role_coverage':sum(r['candidate_roles']!='unclassified' for r in rows),'unclassified':sum(r['candidate_roles']=='unclassified' for r in rows),'lexicons':lex,'cluster_method':'TF-IDF on neighboring paragraphs within scene, 32 SVD components, L2 normalized, KMeans 18, seed 42; cluster labels are lexical, not narrative truth','svd_explained_variance':float(sv.explained_variance_ratio_.sum()),'limitations':'every paragraph processed automatically, not exhaustive human semantic reading; markers can be absent or misleading; names nonexhaustive; scene breaks author markers not necessarily dramatic boundaries'},indent=2));Path('/tmp/cfa_scene_review.txt').write_text('\n'.join(samples)); print((out/'method.json').read_text())
