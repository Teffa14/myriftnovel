import re,sys,zipfile,json,csv,collections as C,pathlib,hashlib,functools
from bs4 import BeautifulSoup
from textblob.en import tag
from importlib.metadata import version
P=pathlib.Path(sys.argv[1]); O=pathlib.Path(sys.argv[2]); O.mkdir(parents=True,exist_ok=True)
W=re.compile(r"[A-Za-z0-9]+(?:[’'\-][A-Za-z0-9]+)*"); Q=re.compile(r'“[^”]*”|"[^"\n]*"'); NOTE=re.compile(r"^(?:T/N\s*:|TL/N\s*:|Translator(?:’|')?s?\s+Note\s*:|Editor(?:’|')?s?\s+Note\s*:|Announcement\s*:|Also, please check out the Author)",re.I)
L={k:re.compile(r'\b(?:'+v+r')\b',re.I) for k,v in {
'combat':r'attack(?:s|ed|ing)?|damage|hit(?:s|ting)?|dodge(?:s|d|ing)?|block(?:s|ed|ing)?|skills?|combos?|counterattack|cooldown|health|mana|weapons?|shots?|strikes?',
'decision':r'decid(?:e|ed|es|ing)|cho(?:ose|se|sen|osing)|plan(?:s|ned|ning)?|strateg(?:y|ies|ic)|tactic(?:s|al)?|options?|risk(?:s|ed|ing)?|consider(?:s|ed|ing)?',
'explanation':r'because|therefore|thus|however|in other words|in fact|as a result|for example|which meant|the reason|due to|otherwise|if|unless',
'uncertainty':r'perhaps|maybe|probably|possibly|might|could|wonder(?:ed|ing)?|suspect(?:ed|ing)?|guess(?:ed|ing)?|uncertain|unlikely',
'urgency':r'suddenly|immediately|quickly|instantly|urgent|hurry|seconds?|too late|at once|no time|last chance',
'stakes':r'win(?:s|ning)?|won|los(?:e|es|t|ing)|defeat(?:s|ed)?|victory|eliminat(?:e|ed|ion)|crucial|danger|pressure|desperate|final',
'reversal':r'but|however|instead|unexpected(?:ly)?|surpris(?:e|ed|ing)|yet|although|nevertheless|even so',
'cognition':r'think(?:s|ing)?|thought|knew|know(?:s|ing)?|realiz(?:e|ed|ing)|underst(?:and|ood)|notic(?:e|ed|ing)|remember(?:ed|s)?|expect(?:ed|s)?',
'emotion':r'angry|anger|happy|sad|fear|afraid|nervous|anxious|excited|shock(?:ed)?|surpris(?:ed|e)|smil(?:e|ed|ing)|laugh(?:ed|ing)?|sigh(?:ed|ing)?|cry(?:ing)?|tears',
'sensory':r'look(?:ed|ing|s)?|saw|see(?:ing|s)?|heard|hear(?:ing|s)?|sounds?|voices?|felt|feel(?:ing|s)?|eyes|face|hands?|light|dark|silent|silence',
'institution':r'teams?|clubs?|guilds?|managers?|captains?|sponsors?|contracts?|tournaments?|playoffs?|league|championship',
'spectator':r'audience|spectators?|fans?|viewers?|commentators?|broadcast|crowd',
'economic':r'money|prices?|costs?|salary|contracts?|sponsors?|budget|paid|pay(?:s|ing)?|profit|rent',
'social':r'friends?(?:hip)?|family|roommates?|teammates?|talk(?:ed|ing)?|chat(?:ted|ting)?|smil(?:e|ed|ing)|laugh(?:ed|ing)?|thank(?:s|ed)?|apolog(?:y|ize|ized)',
 'temporal':r'then|now|after|before|when|while|later|finally|first|next|already|still|again|soon','space':r'left|right|behind|ahead|above|below|near|far|distance|position|corner|room|door|ground|screen'}.items()}
NAMES='Ye Xiu|Chen Guo|Tang Rou|Su Mucheng|Wei Chen|Mo Fan|Sun Xiang|Huang Shaotian|Yu Wenzhou|Wang Jiexi|Han Wenqing|Zhang Xinjie|Zhou Zekai|Fang Rui|Luo Ji|Qiao Yifan|Bao Rongxing|An Wenyi|Xiao Shiqin|Liu Hao|Lin Jingyan|Su Muqiu|Du Ming|Jiang Botao|Wu Yuce|Li Xuan|Lou Guanning|Tao Xuan|Chu Yunxiu|Li Hua|Zhang Jiale|Sun Zheping|Blue River|Lord Grim|Steamed Bun|Soft Mist|Dancing Rain|Deception|Team Happy|Excellent Era|Blue Rain|Tiny Herb|Tyranny|Samsara'.split('|'); NP={n:re.compile(r'\b'+re.escape(n)+r'\b',re.I) for n in NAMES}
A=re.compile(r'\b(said|asked|replied|answered|shouted|yelled|called|whispered|muttered|exclaimed|continued|explained|responded|laughed|sighed|added|remarked|cried|interrupted|retorted|snorted|murmured|sneered|agreed|warned|suggested|ordered|stated)\b',re.I)
STOP=set('a an the and or but if as at by for from in into of on onto to with without is am are was were be been being have has had do does did would could should can will shall may might must it its he him his she her hers they them their theirs we us our ours i me my mine you your yours this that these those there here which who whom whose what when where why how not no yes so than then too very just also only even all any some each every other another more most much many few less over under up down out off again back now still already well really one two first next'.split())
def words(s):return [x.lower() for x in W.findall(s)]
@functools.lru_cache(maxsize=100000)
def word_labels(w):return tuple(k for k,v in L.items() if v.fullmatch(w))
MULTI={"explanation":re.compile(r"\b(?:in other words|in fact|as a result|for example|which meant|the reason|due to)\b",re.I),"urgency":re.compile(r"\b(?:too late|at once|no time|last chance)\b",re.I)}
def lex(s):
 c=C.Counter(k for w in words(s) for k in word_labels(w))
 for k,v in MULTI.items():c[k]+=len(v.findall(s))
 return {k:c[k] for k in L}
def profile(p,x):
 if p.startswith(('“','"')):return 'dialogue'
 for k,ks in [('combat',['combat']),('explanation',['explanation']),('reflection',['cognition','decision']),('description',['sensory','space']),('institution',['institution','economic'])]:
  if sum(x[a] for a in ks)>=2:return k
 return 'other'
def top(c,n=30):return c.most_common(n)
def rate(a,b):return round(1000*a/b,3) if b else 0
rows=[]; segments=[]; mentions=[]; counts={k:C.Counter() for k in ('words','content','verbs','adjectives','adverbs','pos','syntax','sentence_starts','attribution','quoted','outside','profile','dominant','open','close','transitions','pairs','names','name_chapters')}; edge={k:C.Counter() for k in ('open','middle','close')}; bins=[C.Counter() for i in range(5)]; voice={k:C.Counter() for k in ('quoted','outside')}; profile_names=['dialogue','combat','explanation','reflection','description','institution','other']
with zipfile.ZipFile(P) as z:
 ids=sorted(int(re.search(r'chap_(\d+)',n).group(1)) for n in z.namelist() if re.fullmatch(r'EPUB/chap_\d+\.xhtml',n)); assert ids==list(range(1,1730))
 for i in ids[int(sys.argv[3])-1:int(sys.argv[4])] if len(sys.argv)>4 else ids[:-1]:
  soup=BeautifulSoup(z.read(f'EPUB/chap_{i:02d}.xhtml'),'html.parser'); head=int(re.search(r'Chapter\s+(\d+)',soup.h1.get_text()).group(1)); ps=[x.get_text(' ',strip=True) for x in soup.body.find_all('p')]; ps=[p for p in ps if p and not NOTE.match(p)]; t='\n'.join(ps); ws=words(t); n=len(ws); counts['words'].update(ws);counts['content'].update(x for x in ws if x not in STOP and not x.isdigit()); tg=tag(t); tags=[y for x,y in tg];counts['pos'].update(tags);counts['syntax'].update(' '.join(tags[j:j+3]) for j in range(len(tags)-2) if all(a not in ('.',',',':','"','(',')') for a in tags[j:j+3]));
  for k,prefix in [('verbs','VB'),('adjectives','JJ'),('adverbs','RB')]:counts[k].update(x.lower() for x,y in tg if y.startswith(prefix))
  # first 3 POS of each sentence proxy; derived from existing tagged sequence
  st=0
  for j,(x,y) in enumerate(tg):
   if x in ('.','?','!'):
    if j>st:counts['sentence_starts'].update([' '.join(tags[st:min(st+3,j)])]);st=j+1
  px=[lex(p) for p in ps]; pp=[profile(p,x) for p,x in zip(ps,px)]; cc=C.Counter(pp);counts['profile'].update(cc);counts['dominant'].update([cc.most_common(1)[0][0]]);counts['transitions'].update(a+'>'+b for a,b in zip(pp,pp[1:]));counts['open'].update([pp[0]]);counts['close'].update([pp[-1]]);cx=lex(t); row={'chapter':i,'heading_number':head,'words':n,'paragraphs':len(ps),'dominant':cc.most_common(1)[0][0],**{'p_'+k:cc[k] for k in profile_names},**cx,'quote_spans':0,'quote_words':0,'near_tag':0,'opening':pp[0],'closing':pp[-1]}
  for p in ps:
   matches=list(Q.finditer(p));row['quote_spans']+=len(matches)
   for m in matches:
    q=words(m.group());row['quote_words']+=len(q);a=A.findall(p[max(0,m.start()-100):m.start()]+' '+p[m.end():m.end()+100]);counts['attribution'].update(x.lower() for x in a);row['near_tag']+=bool(a)
   for k,v in [('quoted',' '.join(m.group() for m in matches)),('outside',Q.sub(' ',p))]:
    ww=words(v);counts[k].update(ww);voice[k].update({'words':len(ww),'question':v.count('?'),'exclamation':v.count('!'),'first_person':sum(x in ('i','me','my','mine','we','us','our','ours') for x in ww),'second_person':sum(x in ('you','your','yours') for x in ww),'third_person':sum(x in ('he','she','him','her','his','they','them','their') for x in ww),**lex(v)})
  for k,p in [('open',ps[0]),('middle',ps[len(ps)//2]),('close',ps[-1])]:edge[k].update({'words':len(words(p)),'paragraphs':1,'question':int('?' in p),'exclamation':int('!' in p),'dialogue_start':int(p.startswith(('“','"'))),'short':int(len(words(p))<=10),**lex(p)})
  for b in range(5):
   seg=ps[len(ps)*b//5:len(ps)*(b+1)//5]; s='\n'.join(seg); d={'words':len(words(s)),'paragraphs':len(seg),**lex(s),'question':s.count('?'),'exclamation':s.count('!'),'short':sum(len(words(p))<=10 for p in seg),'quote_words':sum(len(words(m.group())) for p in seg for m in Q.finditer(p))};bins[b].update(d);segments.append({'chapter':i,'segment':b+1,**d})
  ns={k:len(v.findall(t)) for k,v in NP.items()};active=[k for k,v in ns.items() if v];counts['names'].update(ns);counts['name_chapters'].update(active);counts['pairs'].update(a+'|'+b for j,a in enumerate(active) for b in active[j+1:]);mentions.append({'chapter':i,**ns});rows.append(row)
  if i%400==0:print(i,flush=True)
assert len(rows)==(int(sys.argv[4])-int(sys.argv[3])+1 if len(sys.argv)>4 else 1728)
N=sum(r['words'] for r in rows); PN=sum(r['paragraphs'] for r in rows)
(O/'raw.json').write_text(json.dumps({'edge':edge,'bins':bins,'voice':voice}))
def write(name,rr):
 with (O/name).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
write('deep_chapter_metrics.csv',rows);write('tension_segments.csv',segments);write('character_mentions.csv',mentions)
for k,c in counts.items():write(k+'.csv',[{'term':a,'count':b} for a,b in c.most_common()])
blocks=[]
for j in range(0,len(rows),100):
 rr=rows[j:j+100];nn=sum(r['words'] for r in rr);pn=sum(r['paragraphs'] for r in rr);blocks.append({'range':f'{j+1}-{j+len(rr)}','words':nn,'quoted_pct':round(100*sum(r['quote_words'] for r in rr)/nn,2),**{k:rate(sum(r[k] for r in rr),nn) for k in L},**{k:round(100*sum(r['p_'+k] for r in rr)/pn,2) for k in profile_names}})
def edge_summary(v):return {'words':v['words'],'paragraphs':v['paragraphs'],**{k:round(100*v[k]/v['paragraphs'],2) for k in ('question','exclamation','dialogue_start','short')},**{k:rate(v[k],v['words']) for k in L}}
res={'sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'versions':{'textblob':version('textblob'),'beautifulsoup4':version('beautifulsoup4')},'chapters':len(rows),'words':N,'paragraphs':PN,'unique_words':len(counts['words']),'top':{k:top(c,50) for k,c in counts.items()},'quote_spans':sum(r['quote_spans'] for r in rows),'quote_spans_near_tag':sum(r['near_tag'] for r in rows),'voice':{k:{'words':v['words'],**{a:rate(b,v['words']) for a,b in v.items() if a!='words'}} for k,v in voice.items()},'edges':{k:edge_summary(v) for k,v in edge.items()},'segments':[{'segment':i+1,'words':v['words'],'paragraphs':v['paragraphs'],'quote_pct':round(100*v['quote_words']/v['words'],2),'short_pct':round(100*v['short']/v['paragraphs'],2),**{k:rate(v[k],v['words']) for k in [*L,'question','exclamation']}} for i,v in enumerate(bins)],'blocks':blocks,'lexicons':{k:v.pattern for k,v in L.items()},'limitations':['English translation; POS estimates from TextBlob, not lemmatized; POS trigrams may cross sentences.','Quote proxies may miss dialogue or include non-dialogue; nearby tag not speaker attribution.','Paragraph labels ordered lexical heuristics, not scenes.','Tension signals are proxies; quintiles by paragraph count, not actual beats.','Name counts literal, aliases separate, cooccurrence not a relationship.','No full semantic reading or claims of causation.']}
(O/'deep_metrics.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)); print('DONE',N,PN,flush=True)
