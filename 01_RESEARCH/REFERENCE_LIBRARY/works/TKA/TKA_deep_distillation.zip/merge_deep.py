import csv,json,collections as C,pathlib,sys
P=pathlib.Path(sys.argv[1]); O=pathlib.Path(sys.argv[2]);O.mkdir(exist_ok=True,parents=True); parts=sorted(p for p in P.iterdir() if p.is_dir());assert len(parts)==4
def read(p):
 with p.open(encoding='utf-8') as f:return list(csv.DictReader(f))
def write(p,rows):
 with p.open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for name in ('deep_chapter_metrics.csv','tension_segments.csv','character_mentions.csv'):
 r=[x for p in parts for x in read(p/name)];write(O/name,r)
rows=read(O/'deep_chapter_metrics.csv');assert [int(r['chapter']) for r in rows]==list(range(1,1729)); N=sum(int(r['words']) for r in rows); PN=sum(int(r['paragraphs']) for r in rows);assert N==3154011 and PN==100530
r0=json.loads((parts[0]/'deep_metrics.json').read_text()); counts={}
for p in parts:
 for file in p.glob('*.csv'):
  if file.name in ('deep_chapter_metrics.csv','tension_segments.csv','character_mentions.csv'):continue
  c=counts.setdefault(file.stem,C.Counter());c.update({r['term']:int(r['count']) for r in read(file)})
for k,c in counts.items():write(O/(k+'.csv'),[{'term':a,'count':b} for a,b in c.most_common()])
edge={k:C.Counter() for k in ('open','middle','close')};bins=[C.Counter() for i in range(5)];voice={k:C.Counter() for k in ('quoted','outside')}
for p in parts:
 raw=json.loads((p/'raw.json').read_text());
 for k in edge:edge[k].update(raw['edge'][k])
 for k in voice:voice[k].update(raw['voice'][k])
 for i in range(5):bins[i].update(raw['bins'][i])
L=list(r0['lexicons']);rate=lambda a,b:round(1000*a/b,3) if b else 0
blocks=[]
for j in range(0,1728,100):
 rr=rows[j:j+100];n=sum(int(r['words']) for r in rr);pn=sum(int(r['paragraphs']) for r in rr);blocks.append({'range':f'{j+1}-{j+len(rr)}','words':n,'quote_pct':round(100*sum(int(r['quote_words']) for r in rr)/n,2),**{k:rate(sum(int(r[k]) for r in rr),n) for k in L},**{k:round(100*sum(int(r[k]) for r in rr)/pn,2) for k in rr[0] if k.startswith('p_')}})
res={**{k:r0[k] for k in ('sha256','versions','lexicons','limitations')},'chapters':1728,'words':N,'paragraphs':PN,'unique_words':len(counts['words']),'top':{k:c.most_common(50) for k,c in counts.items()},'quote_spans':sum(int(r['quote_spans']) for r in rows),'quote_spans_near_tag':sum(int(r['near_tag']) for r in rows),'voice':{k:{'words':v['words'],**{a:rate(b,v['words']) for a,b in v.items() if a!='words'}} for k,v in voice.items()},'edges':{k:{'words':v['words'],'paragraphs':v['paragraphs'],**{a:round(100*v[a]/v['paragraphs'],2) for a in ('question','exclamation','dialogue_start','short')},**{a:rate(v[a],v['words']) for a in L}} for k,v in edge.items()},'segments':[{'segment':i+1,'words':v['words'],'paragraphs':v['paragraphs'],'quote_pct':round(100*v['quote_words']/v['words'],2),'short_pct':round(100*v['short']/v['paragraphs'],2),**{k:rate(v[k],v['words']) for k in [*L,'question','exclamation']}} for i,v in enumerate(bins)],'blocks':blocks}
(O/'deep_metrics.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));print(json.dumps({k:res[k] for k in ('chapters','words','paragraphs','unique_words','quote_spans','quote_spans_near_tag','voice','edges','segments')},indent=2));
for k in ('words','content','verbs','adjectives','adverbs','syntax','sentence_starts','attribution','profile','dominant','open','close','transitions','names','name_chapters','pairs'):print(k,counts[k].most_common(15))
