import csv,re,sys,json,hashlib,zipfile,collections as C,itertools,pathlib
from lxml import etree
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.cluster import KMeans
import numpy as np
P=pathlib.Path(sys.argv[1]); O=pathlib.Path(sys.argv[2]);O.mkdir(exist_ok=True,parents=True)
# Explicit surface cues. These are candidate narrative functions, not confirmed plot events.
LEX={
'goal':'want wants wanted need needs needed hope hopes hoped goal objective must intend intends intended try tries tried',
'decision':'decide decides decided choose chooses chose chosen opted refused agreed',
'obstacle':'unable impossible difficulty difficult problem obstacle forced failed blocked prevented',
'preparation':'prepare prepared preparing preparation training practice practiced planned planning analyzed analysed reviewed testing',
'attack':'attack attacks attacked attacking struck hit shot damage combo skill skills',
'response':'dodge dodged dodging block blocked blocking counter countered counterattack retreat retreated avoid avoided interrupt interrupted reacted',
'reversal':'however instead unexpected unexpectedly surprised yet',
'outcome':'won lost victory defeat defeated eliminated succeeded failed result finished ended',
'learning':'learn learned learnt realized understood recognized discovered mistake lesson improved adapted',
'uncertainty':'maybe perhaps probably might could wondered uncertain suspected whether',
'explanation':'because therefore thus otherwise if unless consequently',
'affiliation':'joined recruit recruited recruitment invited offered accepted hired signed quit retired transfer transferred contract sponsor team guild club',
'cooperation':'help helped helping support supported trust trusted cooperation protect protected assist assisted thanked agreed together partner',
'conflict':'argued argument disagreed refused accused blamed criticized rival rivalry opponent challenge challenged betrayal angry anger',
'emotion':'afraid fear nervous anxious worried excited happy sad disappointed shock shocked relief relieved proud regret smiled laughed sighed tears',
'economic':'money salary price cost paid pay budget rent profit contract sponsor buy bought sold expensive cheap',
'public':'audience spectator spectators fans viewers commentators broadcast crowd reporters interview media reputation',
'competitive':'match matches tournament championship playoffs competition league round score ranking opponent battle arena',
'everyday':'breakfast lunch dinner food restaurant sleep bed home room cafe coffee phone family friend',
'urgency':'suddenly immediately quickly instantly seconds hurry desperate crucial',
'stakes':'must risk danger pressure elimination championship final lose loss win victory'}
lookup=C.defaultdict(list)
for r,ss in LEX.items():
 for s in ss.split():lookup[s].append(r)
N='Ye Xiu|Ye Qiu|Chen Guo|Tang Rou|Su Mucheng|Wei Chen|Mo Fan|Sun Xiang|Huang Shaotian|Yu Wenzhou|Wang Jiexi|Han Wenqing|Zhang Xinjie|Zhou Zekai|Fang Rui|Luo Ji|Qiao Yifan|Bao Rongxing|An Wenyi|Xiao Shiqin|Liu Hao|Lin Jingyan|Su Muqiu|Du Ming|Jiang Botao|Wu Yuce|Li Xuan|Lou Guanning|Tao Xuan|Chu Yunxiu|Li Hua|Zhang Jiale|Sun Zheping|Blue River|Lord Grim|Steamed Bun|Soft Mist|Dancing Rain|Deception|Team Happy|Excellent Era|Blue Rain|Tiny Herb|Tyranny|Samsara'.split('|')
ND={tuple(n.lower().split()):n for n in N}; persons=set(N[:34]); W=re.compile(r"[A-Za-z0-9]+(?:['’\-][A-Za-z0-9]+)*"); S=re.compile(r'(?<=[.!?])\s+'); NOTE=re.compile(r"^(?:T/N\s*:|TL/N\s*:|Translator(?:’|')?s?\s+Note\s*:|Editor(?:’|')?s?\s+Note\s*:|Announcement\s*:|Also, please check out the Author)",re.I)
NEG={'not','never','no','cannot',"couldn't","didn't","wouldn't","won't","without"}; EVENT={'goal','decision','obstacle','outcome','learning','affiliation','emotion'}; PAIR={'cooperation','conflict','affiliation','emotion','attack','response'}; ACTION=EVENT|PAIR|{'economic','preparation'}
def names(ts):return [(j,ND[k]) for j in range(len(ts)) for k in (tuple(ts[j:j+2]),tuple(ts[j:j+1])) if k in ND]
def write(fn,rows):
 with (O/fn).open('w',newline='',encoding='utf8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
rows=[]; events=[]; pairs=[]; characters=[]; segments=[]; docs=[]; transitions=C.Counter(); totals=C.Counter()
with zipfile.ZipFile(P) as z:
 for i in range(1,1729):
  root=etree.fromstring(z.read(f'EPUB/chap_{i:02d}.xhtml')); h=''.join(root.xpath('//*[local-name()="h1"]')[0].itertext()); hn=int(re.search(r'Chapter\s+(\d+)',h).group(1)); ps=[' '.join(''.join(p.itertext()).split()) for p in root.xpath('//*[local-name()="body"]//*[local-name()="p"]')];ps=[p for p in ps if p and not NOTE.match(p)]; c=C.Counter(); ents=C.Counter(); ac=C.defaultdict(C.Counter); pc=C.defaultdict(C.Counter); bins=[C.Counter() for _ in range(5)]; evidence=C.defaultdict(list); prev=set(); opening=[];closing=[]; n=0; topic_tokens=[]
  for j,p in enumerate(ps,1):
   b=bins[min(4,(j-1)*5//len(ps))]; local=C.Counter()
   for k,s in enumerate(S.split(p),1):
    ts=W.findall(s.lower());n+=len(ts);b['words']+=len(ts); hits=C.Counter(r for t in ts for r in lookup.get(t,()));local.update(hits); ns=names(ts); ents.update(a for _,a in ns); ppl=sorted({a for _,a in ns if a in persons}); active=set(hits)&ACTION
    # Topic model uses full text, excluding known proper-name tokens.
    topic_tokens.extend(ts)
    if not ppl:continue
    for a in ppl: ac[a].update({r:hits[r] for r in active})
    for a in active&EVENT:
     # Strict adjacency identifies a possible named grammatical subject; may still be quoted/hypothetical.
     subject=sorted({nm for pos,nm in ns if nm in persons and any(a in lookup.get(t,()) for t in ts[pos+2:pos+5])});
     events.append({'chapter':i,'heading':hn,'paragraph':j,'sentence':k,'role':a,'names':'|'.join(ppl),'possible_subject':'|'.join(subject),'negation':int(bool(set(ts)&NEG)),'quote':int('"' in s or '“' in s or '”' in s)})
    for pair in itertools.combinations(ppl,2):pc[pair].update({r:hits[r] for r in active&PAIR})
   c.update(local);b.update(local); b['questions']+=p.count('?');b['exclamations']+=p.count('!');active=set(local)
   for a in active:
    if len(evidence[a])<3:evidence[a].append(j)
   for a in prev:
    for bb in active:transitions[a,bb]+=1
   prev=active
   if j==1:opening=sorted(active)
   closing=sorted(active)
  nameset={t for key in ND for t in key}; docs.append(' '.join(t for t in topic_tokens if t not in nameset))
  for name,v in ents.items():
   if name in persons:characters.append({'chapter':i,'name':name,'mentions':v,**{r:ac[name][r] for r in sorted(ACTION)}})
  for (a,b),v in pc.items():
   if v:pairs.append({'chapter':i,'a':a,'b':b,**{r:v[r] for r in sorted(PAIR)}})
  row={'chapter':i,'heading_number':hn,'words':n,'paragraphs':len(ps),**{r:c[r] for r in LEX},'entities':'|'.join(a for a,_ in ents.most_common(5)),'opening':'|'.join(opening),'closing':'|'.join(closing),'evidence':';'.join(r+':'+','.join(map(str,vs)) for r,vs in sorted(evidence.items()))}
  for r in ('goal','obstacle','decision','attack','response','reversal','outcome','learning','explanation','urgency'):
   arr=[1000*b[r]/max(1,b['words']) for b in bins];row['peak_'+r]=int(np.argmax(arr))+1 if max(arr)>0 else 0
  row['tension_delta']=round(sum(1000*bins[-1][r]/max(1,bins[-1]['words'])-1000*bins[0][r]/max(1,bins[0]['words']) for r in ('urgency','stakes','questions','exclamations')),3);rows.append(row)
  for j,b in enumerate(bins,1):segments.append({'chapter':i,'segment':j,**{r:b[r] for r in ('words',*LEX,'questions','exclamations')}})
  if i%432==0:print('processed',i,flush=True)
# Save extraction before fitting anything.
for fn,data in [('chapter_semantic.csv',rows),('candidate_events.csv',events),('character_context.csv',characters),('pair_context.csv',pairs),('segment_roles.csv',segments),('role_transitions.csv',[{'from':a,'to':b,'count':n} for (a,b),n in transitions.most_common()])]:write(fn,data)
assert len(rows)==1728 and len(segments)==8640
summary={'source_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'chapters':len(rows),'words':sum(r['words'] for r in rows),'segments':len(segments),'events':len(events),'adjacent_subject_candidates':sum(bool(e['possible_subject']) for e in events),'character_rows':len(characters),'pair_rows':len(pairs),'role_chapters':{r:sum(x[r]>0 for x in rows) for r in LEX},'positive_tension_delta':sum(r['tension_delta']>0 for r in rows),'heading_mismatches':sum(r['chapter']!=r['heading_number'] for r in rows),'scope':'contextual lexical cues, not certified semantic interpretation or verified plot facts'}
(O/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
# Lightweight corpus theme clustering. No language model assumed.
X=TfidfVectorizer(stop_words='english',min_df=8,max_df=.7,max_features=5000,sublinear_tf=True).fit_transform(docs)
A=np.array([[1000*r[k]/r['words'] for k in LEX] for r in rows]);Z=(A-A.mean(axis=0))/np.maximum(A.std(axis=0),1e-8);V=TruncatedSVD(n_components=16,n_iter=2,random_state=42).fit_transform(X); labels=KMeans(n_clusters=12,n_init=1,random_state=42).fit_predict(V)
# Derive candidate narrative clusters from cue enrichment (not verbatim excerpts).
roles=list(LEX); topics=[]
for k in range(12):
 mask=labels==k;topics.append({'id':k,'chapters':int(mask.sum()),'salient_roles':'|'.join(roles[j] for j in np.argsort(Z[mask].mean(axis=0))[-5:][::-1])})
for i,r in enumerate(rows):r['topic']=int(labels[i]);r['salient_roles']='|'.join(roles[j] for j in np.argsort(Z[i])[-3:][::-1] if A[i,j]>0)
windows=[]
for j in range(0,1728,24):
 ns=C.Counter(n for r in rows[j:j+24] for n in r['entities'].split('|') if n);windows.append({'start':j+1,'end':j+24,'clusters':'|'.join(str(a) for a,_ in C.Counter(labels[j:j+24]).most_common(3)),'salient_roles':'|'.join(roles[k] for k in np.argsort(Z[j:j+24].mean(axis=0))[-3:][::-1]),'entities':'|'.join(a for a,_ in ns.most_common(5))})
write('chapter_semantic.csv',rows);write('clusters.csv',topics);write('windows.csv',windows);summary.update({'clusters':topics,'windows':len(windows),'scope':summary['scope']+'; TF-IDF/SVD/kmeans exploratory theme clusters'});(O/'summary.json').write_text(json.dumps(summary,indent=2));print('complete',json.dumps(summary),flush=True)
